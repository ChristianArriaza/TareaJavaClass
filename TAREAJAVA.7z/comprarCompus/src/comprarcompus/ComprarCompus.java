
package comprarcompus;
import java.util.*;

public class ComprarCompus {

   
    public static void main(String[] args) {
        
        Scanner com = new Scanner(System.in);
        int ram, discoDuro;
        String tipo;
        System.out.println("Bienvenido a DOBLE CLICK");
        System.out.println(" ");
        System.out.println("Describa las caracteristicas de la computadora que busca");
        System.out.println(" ");
        System.out.print("Memora RAM: ");
        ram = com.nextInt();
        System.out.print("Capacidad de Disco Duro: ");
        discoDuro = com.nextInt();
        System.out.print("Tipo de Disco Duro (SSD / HDD)");
        tipo = com.nextLine();
        tipo = com.nextLine();
        System.out.println(" ");
        System.out.println(" ");
        
        compusSeleccion hp = new compusSeleccion();
        
        hp.setRam(ram);
        hp.setDiscoDuro(discoDuro);
        hp.setTipo(tipo);
        hp.retornarCompu();
    }
    
}
