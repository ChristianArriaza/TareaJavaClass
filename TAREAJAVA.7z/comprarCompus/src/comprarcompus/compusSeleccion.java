
package comprarcompus;

public class compusSeleccion {
    
    public int ram, discoDuro;
    public String tipo;

    public compusSeleccion() {
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    public int getDiscoDuro() {
        return discoDuro;
    }

    public void setDiscoDuro(int discoDuro) {
        this.discoDuro = discoDuro;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public void retornarCompu(){
    
        if(ram == 16 && discoDuro == 1){
            System.out.println("Con las descripciones solicitadas disponemos de: ");
            System.out.println(" ");
            System.out.println("LA HP OMEN 15-DC1079WM I7-9750H");
            System.out.println("LA MSI LEOPARD GL65 10SFK-062US I7-10750H");
        }
        if(ram == 8 && discoDuro == 1){
            System.out.println("Con las descripciones solicitadas disponemos de: ");
            System.out.println(" ");
            System.out.println("HP OMEN 15-DC1079WM I7-9750H");
            System.out.println("MSI LEOPARD GL65 10SFK-062US I7-10750H");
        }    
        if(ram == 16 && discoDuro == 512){
            System.out.println("Con las descripciones solicitadas disponemos de: ");
            System.out.println(" ");
            System.out.println("ASUS TUF FA506IV-BR7N12 AMD RYZEN 7");
            System.out.println("HP 15-DK0045CL I7-9750H");
        }    
        if(ram == 8 && discoDuro == 512){
            System.out.println("Con las descripciones solicitadas disponemos de: ");
            System.out.println(" ");
            System.out.println("LENOVO LEGION Y540-15IRH");
            System.out.println("ASUS ROG ZEPHYRUS GA502");     
    }
if(ram == 4 && discoDuro == 512){
            System.out.println("Con las descripciones solicitadas disponemos de: ");
            System.out.println(" ");
            System.out.println("LENOVO LEGION Y540-15IRH");
            System.out.println("ASUS ROG ZEPHYRUS GA502");
        }
    }
}

