
package sistemabarberia;

import java.util.*;

public class SistemaBarberia {


    public static void main(String[] args) {
        Scanner con = new Scanner(System.in);
        String dia, hora, tipo, motivo;

        System.out.print("Ingrese el día de consulta: ");
        dia = con.nextLine();
        System.out.print("Ingrese la hora de consulta: ");
        hora = con.nextLine();
        System.out.print("Ingrese el tipo de corte (hombre/mujer): ");
        tipo = con.nextLine();
        System.out.print("Ingrese el motivo de la consulta: ");
        motivo = con.nextLine();
        
        
        //clasePOLIZA cp = new clasePOLIZA();
        //cp.setNombre(nombre);
        //cp.setDireccion(direccion);
        //cp.verDatos();
        
        claseBarberia bar = new claseBarberia();
        bar.setDia(dia);
        bar.setHora(hora);
        bar.setTipo(tipo);
        bar.setMotivo(motivo);
        bar.retornarDatosBarberia();
    }
    
}
