package sistemabarberia;

public class claseBarberia {

    public String dia, hora, tipo, motivo;

    public claseBarberia() {

    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public void retornarDatosBarberia() {

        //dia, hora, tipo, motivo
        System.out.println("\n");
        System.out.println("Cita agendada exitosamente");
        System.out.println(" ");
        System.out.println("Dia: " + dia);
        System.out.println("Hora: " + hora);
        System.out.println("Tipo: " + tipo);
        System.out.println("Motivo: " + motivo);
        System.out.println(" ");
        System.out.println("Recuerde presentarse 10 minutos antes!");
    }

}
