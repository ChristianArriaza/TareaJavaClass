package t1veterinaria;

import java.util.*;

public class T1VETERINARIA {

    public static void main(String[] args) {

        menu();

    }

    public static void menu() {

        Scanner scan = new Scanner(System.in);
        int transaccion;

        System.out.println("*****VETERIANARIA EL ARCA DE NOE*****");
        System.out.println("                                     ");
        System.out.println("1. CONSULTA MÉDICA                   ");
        System.out.println("2. FACTURACION                       ");
        System.out.println("3. SALIR                             ");
        System.out.println("                                     ");
        System.out.println("*************************************");
        System.out.println(" ");
        System.out.print("Elige una opción: ");
        transaccion = scan.nextInt();

        switch (transaccion) {

            case 1:
                generaConsulta();
                break;

            case 2:
                facturacion();
                break;

            case 3:
                System.out.println("Presiona cualquier tecla para salir");
                break;

            default:
                System.out.println("Opción incorrecta, presione enter para volver al menu: ");
                menu();
                break;
        }
    }

    public static void generaConsulta() {
        Scanner con = new Scanner(System.in);
        String dia, hora, tipo, motivo;

        System.out.print("Ingrese el día de consulta: ");
        dia = con.nextLine();
        System.out.print("Ingrese la hora de consulta: ");
        hora = con.nextLine();
        System.out.print("Ingrese el tipo de animal: ");
        tipo = con.nextLine();
        System.out.print("Ingrese el motivo de la consulta: ");
        motivo = con.nextLine();

        System.out.println("\n");
        System.out.println("¡Usted agendo exitosamente la cita!");
        System.out.println(" ");
        System.out.println("Su cita es el día " + dia + " a las " + hora + " horas");
        System.out.println("El paciente es un " + tipo + " que tiene " + motivo);
        System.out.println(" ");
        System.out.println("Presentarse 10 minutos antes de su cita");
    }

    public static void facturacion() {
        Scanner factura = new Scanner(System.in);
        String nombre, direccion, descripcion, op;
        int nit, tel;
        double precio, precioTotal;
        System.out.println("\n");
        System.out.print("Ingrese el nombre del cliente: ");
        nombre = factura.nextLine();
        System.out.print("Ingrese el Nit: ");
        nit = factura.nextInt();
        System.out.print("Ingrese el número teléfonico: ");
        tel = factura.nextInt();
        System.out.print("Ingrese la dirección: ");
        direccion = factura.nextLine();
        direccion = factura.nextLine();
        System.out.print("Ingrese el precio neto: ");
        precio = factura.nextDouble();
        System.out.println("\n");
        System.out.print("¿Desea imprimir su factura? (S/N): ");
        op = factura.nextLine();
        op = factura.nextLine();

        if (op.equals("S") || op.equals("s")) {
            System.out.println("\n");
            System.out.println("\n");
            System.out.println("");
            precioTotal = precio * 0.12;
            System.out.println("\n");
            System.out.println("------------------------------------------------");
            System.out.println("|              FACTURA ELECTRONICA             |");
            System.out.println("|            VETERINARIA ARCA DE NOE           |");
            System.out.println("|                Nit: 8145229-2                |");
            System.out.println("|                Tel: 32278744                 |");
            System.out.println("|       4ta Av. 6-03 Zona 9, Guatemala         |");
            System.out.println("|----------------------------------------------|");
            System.out.println("|                                              |");
            System.out.println("|                                              |");
            System.out.println("|   Nombre: " + nombre + "|");
            System.out.println("|   Nit: " + nit + " " + "Telefono: " + tel + "|");
            System.out.println("|   Dirección: " + direccion + "|");
            System.out.println("|                                              |");
            System.out.println("|----------------------------------------------|");
            System.out.println("|                                              |");
            System.out.println("|                 DESCRIPCION                  |");
            System.out.println("|    1 Consulta                       "  + precio + "|");
            System.out.println("|                                              |");
            System.out.println("|                                              |");
            System.out.println("|                                              |");
            System.out.println("|                                              |");
            System.out.println("|       Iva: " + precioTotal + "|");
            System.out.println("|                                              |");
            System.out.println("|   ¡GRACIAS POR SU COMPRA!, Vuelva pronto     |");
            System.out.println("|                                              |");
            System.out.println("----------------------------------------------");
        } else if (op.equals("N") || op.equals("n")) {
            System.out.println("\n");
            System.out.println("¡FACTURACIÓN EXITOSA!");
            System.out.println("\n");
            System.out.println("SONRIA AL CLIENTE :)");

        }

    }

}
